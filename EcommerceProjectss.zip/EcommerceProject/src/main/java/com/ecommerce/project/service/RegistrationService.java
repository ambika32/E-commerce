package com.ecommerce.project.service;

import com.ecommerce.project.Config.response.LoginReponse;
import com.ecommerce.project.DTO.LoginDTO;
import com.ecommerce.project.DTO.RegistrationDTO;


public interface RegistrationService {
	String addRegistration(RegistrationDTO registrationDTO);
	LoginReponse loginRegistration(LoginDTO loginDTO);
}
