package com.ecommerce.project.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.project.DTO.PaymentDTO;
import com.ecommerce.project.exception.PaymentNotFoundException;
import com.ecommerce.project.model.Payment;
import com.ecommerce.project.repository.PaymentRepo;
@Service
public class PaymentServiceIMP implements PaymentService{
	@Autowired
	private PaymentRepo paymentRepo;

	@Override
	public PaymentDTO processPayment(PaymentDTO paymentDTO) {
		Payment payment=new Payment();
		payment.setOrderId(paymentDTO.getOrderId());
		payment.setPaymentMethod(paymentDTO.getPaymentMethod());
		payment.setCardholderName(paymentDTO.getCardholderName());
		payment.setCardNumber(paymentDTO.getCardNumber());
		payment.setExpirationDate(paymentDTO.getExpirationDate());
		payment.setCvv(paymentDTO.getCvv());
		paymentRepo.save(payment);
		return paymentDTO;
	}

	@Override
	public PaymentDTO getPaymentById(Long paymentId) {
		Payment payment=paymentRepo.findById(paymentId)
				.orElseThrow (() -> new PaymentNotFoundException("Payment Not Found"));
		PaymentDTO paymentDTO=new PaymentDTO(
		payment.getPaymentId(),
		payment.getOrderId(),
		payment.getPaymentMethod(),
		payment.getCardholderName(),
		payment.getCardNumber(),
		payment.getExpirationDate(),
		payment.getCvv()
	);
		return paymentDTO;
		
	}

	@Override
	public List<PaymentDTO> getAllPayments() {
		   List<Payment> payments = paymentRepo.findAll();
		    List<PaymentDTO> paymentDTOList = new ArrayList<>();

		    for (Payment payment : payments) {
		        PaymentDTO paymentDTO = new PaymentDTO(
		            payment.getPaymentId(),
		            payment.getOrderId(),
		            payment.getPaymentMethod(),
		            payment.getCardholderName(),
		            payment.getCardNumber(),
		            payment.getExpirationDate(),
		            payment.getCvv()
		        );

		        paymentDTOList.add(paymentDTO);
		    }
		return  paymentDTOList;
	
	}

	@Override
	public boolean deletePayment(Long paymentId) {
		if (paymentRepo.existsById(paymentId)) {
			paymentRepo.deleteById(paymentId);
			return true;
		}
			else {
				throw new PaymentNotFoundException("Payment Not Found");
			}
		
		
	}

}
