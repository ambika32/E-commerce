package com.ecommerce.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.project.DTO.ProductDTO;
import com.ecommerce.project.service.ProductService;

@RestController
@RequestMapping("/api/v1/product")
@CrossOrigin("*")
public class ProductController {
    @Autowired
    private ProductService productService;

    @PostMapping("/save")
    public String createProduct(@RequestBody ProductDTO productDTO) {
        String id = productService.createProduct(productDTO);
        return id;
    }

    @GetMapping("/getAllproduct")
    public List<ProductDTO> getAllProducts() {
        List<ProductDTO> allProducts = productService.getAllProducts();
        return allProducts;
    }
    @GetMapping("/getproductbyid/{id}")
    public ProductDTO getProductById(@PathVariable(value = "id") int id) {
        ProductDTO product = productService.getProductById(id);
        return product;
    }

    @PutMapping("/update/{id}")
    public String updateProduct(@PathVariable(value = "id") int id, @RequestBody ProductDTO productDTO) {
        String updatedName = productService.updateProduct(id, productDTO);
        return "Product updated successfully. Updated name: " + updatedName;
    }

    @DeleteMapping("/delete/{id}")
    public String deleteProduct(@PathVariable(value = "id") int id) {
        boolean deleteProduct = productService.deleteProduct(id);
        if (deleteProduct) {
            return "Product deleted successfully";
        } else {
            return "Product not found";
        }
    }
}
