package com.ecommerce.project.service;

import java.util.List;

import com.ecommerce.project.DTO.FeedbackDTO;

public interface FeedbackService {
    String addFeedback(FeedbackDTO feedbackDTO);
    List<FeedbackDTO> getAllFeedback();
    String updateFeedback(int id, FeedbackDTO feedbackDTO);
    boolean deleteFeedback(long id);
}

