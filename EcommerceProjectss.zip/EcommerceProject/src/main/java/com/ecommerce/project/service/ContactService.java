package com.ecommerce.project.service;

import java.util.List;

import com.ecommerce.project.DTO.ContactDTO;

public interface ContactService {
	String addContact (ContactDTO contactDTO);
	List<ContactDTO>getAllContact();
	boolean deleteContact(long id);

}
