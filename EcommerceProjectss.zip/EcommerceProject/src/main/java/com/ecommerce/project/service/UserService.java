package com.ecommerce.project.service;

import java.util.List;

import com.ecommerce.project.DTO.RegisterDTO;
import com.ecommerce.project.model.User;

public interface UserService {
    User registerUser(RegisterDTO registerDTO);
    boolean authenticateUser(String email, String password);
    List<User> getAllUsers();
}
