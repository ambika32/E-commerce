package com.ecommerce.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.project.DTO.FeedbackDTO;

import com.ecommerce.project.service.FeedbackService;

@RestController
@RequestMapping("/api/v1/feedback")
@CrossOrigin("*")
public class FeedbackController{
	@Autowired
	private FeedbackService feedbackService;
	
	@PostMapping("/save")
	public ResponseEntity<String> saveFeedback(@RequestBody FeedbackDTO feedbackDTO) {
		String id =feedbackService.addFeedback(feedbackDTO);
		String responseBody ="Id:"+feedbackDTO.getId()
	             +"\nName: " + feedbackDTO.getName()
	            + "\nEmail: " + feedbackDTO.getEmail()
	            + "\nFeedback: " + feedbackDTO.getFeedback();
		return ResponseEntity.status(HttpStatus.OK).body(responseBody);
	}
	@GetMapping("/getAllfeedback")
	public List<FeedbackDTO> getAllFeedback(){
		List<FeedbackDTO> allFeedback=feedbackService.getAllFeedback();
		return allFeedback;
		
	}
	@PutMapping("/updatefeedback/{id}")
	public String updateFeedback(@PathVariable(value = "id") int id, @RequestBody FeedbackDTO feedbackDTO) {
	    String updatedName = feedbackService.updateFeedback(id, feedbackDTO);
	    return "Feedback updated successfully. Updated name: " + updatedName;
	}
	@DeleteMapping("/deletefeedback/{id}")
	public String deletefeedback(@PathVariable(value = "id") int id) {
	    boolean deleteFeedback = feedbackService.deleteFeedback(id);
	    if (deleteFeedback) {
	        return "Feedback deleted successfully";
	    } else {
	        return "Feedback not found";
	    }
	}

}

