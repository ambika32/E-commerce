package com.ecommerce.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.project.DTO.RegisterDTO;
import com.ecommerce.project.model.User;
import com.ecommerce.project.repository.UserRepo;

@Service
public class UserServiceIMP implements UserService {
    @Autowired
    private UserRepo userRepo;

    @Override
    public User registerUser(RegisterDTO registerDTO) {
        String firstname = registerDTO.getFirstname();
        String lastname = registerDTO.getLastname();
        String email = registerDTO.getEmail();
        String password = registerDTO.getPassword();

        if (userRepo.findByEmail(email) != null) {
            throw new RuntimeException("Email already exists");
        }

        User user = new User();
        user.setFirstname(firstname);
        user.setLastname(lastname);
        user.setEmail(email);
        user.setPassword(password);

        return userRepo.save(user);
    }

    @Override
    public boolean authenticateUser(String email, String password) {
        User user = userRepo.findByEmail(email);
        if (user != null) {
            return user.getPassword().equals(password);
        }
        return false;
    }
    @Override
    public List<User> getAllUsers() {
        return userRepo.findAll();
    }

	
}
