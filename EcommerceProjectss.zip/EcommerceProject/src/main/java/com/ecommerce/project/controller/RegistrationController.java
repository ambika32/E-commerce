package com.ecommerce.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.project.Config.response.LoginReponse;
import com.ecommerce.project.DTO.LoginDTO;
import com.ecommerce.project.DTO.RegistrationDTO;

import com.ecommerce.project.service.RegistrationService;


@RestController
@CrossOrigin
@RequestMapping("api/v1/register")
public class RegistrationController {
	

    @Autowired
    private RegistrationService registrationService;

    @PostMapping(path = "/save")
    public String saveRegistration(@RequestBody RegistrationDTO registrationDTO)
    {
   
        String id = registrationService.addRegistration(registrationDTO);
        return id;
    }
    
    @PostMapping(path = "/login")
    public ResponseEntity<?> loginRegistration(@RequestBody LoginDTO loginDTO)
    {
        LoginReponse loginReponse = registrationService.loginRegistration(loginDTO);
        
        return ResponseEntity.ok(loginReponse);
    }

}
