package com.ecommerce.project.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.project.Config.PasswordEncoder;
import com.ecommerce.project.Config.response.LoginReponse;
import com.ecommerce.project.DTO.LoginDTO;
import com.ecommerce.project.DTO.RegistrationDTO;
import com.ecommerce.project.model.Registration;
import com.ecommerce.project.repository.RegistrationRepo;


@Service
public class RegistrationServiceIMP implements RegistrationService{

	@Autowired
    private RegistrationRepo registrationRepo;
	
	  @Autowired
	    private PasswordEncoder passwordEncoder;
	  
	public String addRegistration(RegistrationDTO registrationDTO) {
		
	     Registration registration = new Registration(

	                registrationDTO.getId(),
	                registrationDTO.getName(),
	                registrationDTO.getEmail(),
	               registrationDTO.getPassword(),
	               registrationDTO.getCpassword()
	                
	               

	               //this.passwordview.encod(employeeDTO.getPassword())
	        );

	        registrationRepo.save(registration);

	        return registration.getName();
	}
	RegistrationDTO registrationDTO;
	
	@Override
	public LoginReponse loginRegistration(LoginDTO loginDTO) {
		String msg = "";
        Registration registration1 = registrationRepo.findByEmail(loginDTO.getEmail());
        if (registration1 != null) {
            String password = loginDTO.getPassword();
            String encodedPassword = registration1.getPassword();
            Boolean isPwdRight = passwordEncoder.matches(password, encodedPassword);
            if (isPwdRight) {
                Optional<Registration> registration = registrationRepo.findOneByEmailAndPassword(loginDTO.getEmail(), encodedPassword);
                if (registration.isPresent()) {
                    return new LoginReponse("Login Success", true);
                } else {
                    return new LoginReponse("Login Failed", false);
                }
            } else {
                return new LoginReponse("password Not Match", false);
            }
        }else {
            return new LoginReponse("Email not exits", false);
        }
    }
	
	


}
