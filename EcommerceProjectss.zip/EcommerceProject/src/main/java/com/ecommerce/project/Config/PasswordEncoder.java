package com.ecommerce.project.Config;

public class PasswordEncoder {

	public Boolean matches(String password, String encodedPassword) {
		// TODO Auto-generated method stub
		return null;
	}

	public String encod(String password) {
		// TODO Auto-generated method stub
		return null;
	}

	public Object encode(String password) {
		// TODO Auto-generated method stub
		return null;
	}

}
