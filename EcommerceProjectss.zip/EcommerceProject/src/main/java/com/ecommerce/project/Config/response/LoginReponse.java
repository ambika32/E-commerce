package com.ecommerce.project.Config.response;

public class LoginReponse {
	 String message;
	 Boolean status;
	public LoginReponse() {
		super();
		// TODO Auto-generated constructor stub
	}
	public LoginReponse(String message, Boolean status) {
		super();
		this.message = message;
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Boolean getStatus() {
		return status;
	}
	public void setStatus(Boolean status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "LoginReponse [message=" + message + ", status=" + status + "]";
	}
	 
	 
	 
}
