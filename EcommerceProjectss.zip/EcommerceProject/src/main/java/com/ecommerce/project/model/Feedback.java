package com.ecommerce.project.model;

import javax.persistence.*;

@Entity
@Table(name="feedback")
public class Feedback {
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", length = 50)
private long id;
	@Column(name = "name", length = 50)
private String name;
	@Column(name = "email", length = 50)
private String email;
	@Column(name = "feedback", length = 100)
private String feedback;
public Feedback() {
	super();
}
public Feedback(long id, String name, String email, String feedback) {
	super();
	this.id = id;
	this.name = name;
	this.email = email;
	this.feedback = feedback;
}
public long getId() {
	return id;
}
public void setId(long id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getFeedback() {
	return feedback;
}
public void setFeedback(String feedback) {
	this.feedback = feedback;
}
@Override
public String toString() {
	return "Feedback [id=" + id + ", name=" + name + ", email=" + email + ", feedback=" + feedback + "]";
}

}
