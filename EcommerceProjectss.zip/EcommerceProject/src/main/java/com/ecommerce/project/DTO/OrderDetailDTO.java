package com.ecommerce.project.DTO;

public class OrderDetailDTO {
	
	 private Long orderId;
	    private String fullName;
	    private Long contactNumber;
	    private String email;
	    private String address;
	    private Long productId;
		public OrderDetailDTO() {
			super();
			// TODO Auto-generated constructor stub
		}
		public OrderDetailDTO(Long orderId, String fullName, Long contactNumber, String email, String address,
				Long productId) {
			super();
			this.orderId = orderId;
			this.fullName = fullName;
			this.contactNumber = contactNumber;
			this.email = email;
			this.address = address;
			this.productId = productId;
		}
		public Long getOrderId() {
			return orderId;
		}
		public void setOrderId(Long orderId) {
			this.orderId = orderId;
		}
		public String getFullName() {
			return fullName;
		}
		public void setFullName(String fullName) {
			this.fullName = fullName;
		}
		public Long getContactNumber() {
			return contactNumber;
		}
		public void setContactNumber(Long contactNumber) {
			this.contactNumber = contactNumber;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public Long getProductId() {
			return productId;
		}
		public void setProductId(Long productId) {
			this.productId = productId;
		}
		@Override
		public String toString() {
			return "OrderDetailDTO [orderId=" + orderId + ", fullName=" + fullName + ", contactNumber=" + contactNumber
					+ ", email=" + email + ", address=" + address + ", productId=" + productId + "]";
		}
	
	
	

}
