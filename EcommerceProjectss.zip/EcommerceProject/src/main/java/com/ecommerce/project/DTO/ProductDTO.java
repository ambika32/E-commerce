package com.ecommerce.project.DTO;

public class ProductDTO {
	
	private Long productid;
    private String itemName;
    private String description;
    private int price;
    private int quantity;
    private int size;
    private String categoryName;
    private String image;
	public ProductDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ProductDTO(Long productid, String itemName, String description, int price, int quantity, int size,
			String categoryName, String image) {
		super();
		this.productid = productid;
		this.itemName = itemName;
		this.description = description;
		this.price = price;
		this.quantity = quantity;
		this.size = size;
		this.categoryName = categoryName;
		this.image = image;
	}
	public Long getProductid() {
		return productid;
	}
	public void setProductid(Long productid) {
		this.productid = productid;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	@Override
	public String toString() {
		return "ProductDTO [productid=" + productid + ", itemName=" + itemName + ", description=" + description
				+ ", price=" + price + ", quantity=" + quantity + ", size=" + size + ", categoryName=" + categoryName
				+ ", image=" + image + "]";
	}
	
}
