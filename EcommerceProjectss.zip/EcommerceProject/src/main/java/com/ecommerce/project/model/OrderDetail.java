package com.ecommerce.project.model;

import javax.persistence.*;

@Entity
@Table(name="orders")
public class OrderDetail {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "orderId")
	private Long orderid;
	private String fullName;
	private Long contactNumber;
	private String email;
	private String address;
	
	@OneToOne
	private Product product;

	public OrderDetail() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrderDetail(Long orderid, String fullName, Long contactNumber, String email, String address,
			Product product) {
		super();
		this.orderid = orderid;
		this.fullName = fullName;
		this.contactNumber = contactNumber;
		this.email = email;
		this.address = address;
		this.product = product;
	}

	public Long getOrderid() {
		return orderid;
	}

	public void setOrderid(Long orderid) {
		this.orderid = orderid;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public Long getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(Long contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	@Override
	public String toString() {
		return "OrderDetail [orderid=" + orderid + ", fullName=" + fullName + ", contactNumber=" + contactNumber
				+ ", email=" + email + ", address=" + address + ", product=" + product + "]";
	}
	
	

	// Constructors, getters, and setters
}

