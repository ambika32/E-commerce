package com.ecommerce.project.service;

import java.util.List;
import java.util.NoSuchElementException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ecommerce.project.DTO.OrderDetailDTO;
import com.ecommerce.project.model.OrderDetail;
import com.ecommerce.project.model.Product;
import com.ecommerce.project.repository.OrderDetailRepo;
import com.ecommerce.project.repository.ProductRepo;


@Service
public class OrderDetailServiceIMP implements OrderDetailService{
	 
	@Autowired
	private OrderDetailRepo orderDetailRepo;
	
	@Autowired
	private ProductRepo productRepo;
	
	
	@Override
	public OrderDetail placeOrder(OrderDetailDTO orderDetailDTO) {
		 Product product = productRepo.findById(orderDetailDTO.getProductId())
	                .orElseThrow(() -> new NoSuchElementException("Product not found"));


	        OrderDetail orderDetail = new OrderDetail();
	        orderDetail.setFullName(orderDetailDTO.getFullName());
	        orderDetail.setContactNumber(orderDetailDTO.getContactNumber());
	        orderDetail.setAddress(orderDetailDTO.getAddress());
	        orderDetail.setEmail(orderDetailDTO.getEmail());
	        orderDetail.setProduct(product);
	        

	        return orderDetailRepo.save(orderDetail);
	    }


	@Override
	public OrderDetail getorderDetailById(Long orderId) {
		  return orderDetailRepo.findById(orderId)
	                .orElseThrow(() -> new NoSuchElementException("Order detail not found"));
		
	}

	@Override
	public List<OrderDetail> getAllOrderDetails() {
		return orderDetailRepo.findAll();
	}

}
