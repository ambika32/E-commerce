package com.ecommerce.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.project.DTO.ContactDTO;
import com.ecommerce.project.service.ContactService;
@CrossOrigin("*")
@RestController
@RequestMapping("/api/v1/contact")
public class ContactController {
	@Autowired
	private ContactService contactService;
	
	@PostMapping("/save")
	public String addContact(@RequestBody ContactDTO contactDTO) {
		String id=contactService.addContact(contactDTO);
		return id;
	}
	
	@GetMapping ("/getAllcontact")
	public List<ContactDTO> getAllContact(){
		List<ContactDTO> allContacts =contactService.getAllContact();
		return allContacts;
	}
	
	@DeleteMapping("/deletecontact/{id}")
	public String deleteContact(@PathVariable(value = "id") long id) {
	    boolean deleteContact = contactService.deleteContact(id);
	    if (deleteContact) {
	        return "Contact deleted successfully";
	    } else {
	        return "Contact not found";
	    }
	}



}
