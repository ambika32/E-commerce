package com.ecommerce.project.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.project.DTO.ContactDTO;
import com.ecommerce.project.exception.ContactNotFoundException;
import com.ecommerce.project.model.Contact;
import com.ecommerce.project.repository.ContactRepo;

@Service
public class ContactServiceIMP implements ContactService{
	@Autowired
	ContactRepo contactRepo;

	@Override
	public String addContact(ContactDTO contactDTO) {
		Contact contact=new Contact();
		contact.setName(contactDTO.getName());
		contact.setEmail(contactDTO.getEmail());
		contact.setMessage(contactDTO.getMessage());
		Contact savedContact=contactRepo.save(contact);
		
		return savedContact.getName();
	}

	@Override
	public List<ContactDTO> getAllContact() {
	    List<Contact> contactList = contactRepo.findAll();
	    List<ContactDTO> contactDTOList = new ArrayList<>();
	    for (Contact contact : contactList) {
	        ContactDTO contactDTO = new ContactDTO(
	                contact.getId(),
	                contact.getName(),
	                contact.getEmail(),
	                contact.getMessage()
	        );
	        contactDTOList.add(contactDTO);
	    }
	    return contactDTOList;
	}


	
	@Override
	public boolean deleteContact(long id) {
	    if (contactRepo.existsById(id)) {
	        contactRepo.deleteById(id);
	        return true;
	    } else {
	        throw new ContactNotFoundException("Contact Not Found");
	    }
	}



}
