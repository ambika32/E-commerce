package com.ecommerce.project.service;
import com.ecommerce.project.DTO.CartDTO;

public interface CartService {
    CartDTO getCartById(long cartId);
    void addProductToCart(long userId, long productId);
    void removeProductFromCart(long cartId, long productId);
    void deleteCart(long cartId);
}
